
insert into ITEMS values('Apples', 1.99);
insert into ITEMS values('Beef', 4.99);
insert into ITEMS values('Carrots', 2.99);
insert into ITEMS values('Grapes', 1.99);
insert into ITEMS values('Grapefruit', 2.99);
insert into ITEMS values('Banana', 1.99);
insert into ITEMS values('Orange', 0.99);
insert into ITEMS values('Chicken', 5.99);
insert into ITEMS values('Pork', 5.99);
insert into ITEMS values('Turkey', 7.99);
insert into ITEMS values('Fish', 3.99);
insert into ITEMS values('Celery', 1.99);
insert into ITEMS values('Spinach', 2.99);
insert into ITEMS values('Kale', 1.99);
insert into ITEMS values('Broccoli', 2.99);


insert into QUANTITY values('Apples',80);
insert into QUANTITY values('Beef', 20);
insert into QUANTITY values('Carrots',15);
insert into Quantity values('Grapes', 100);
insert into Quantity values('Grapefruit', 24);
insert into Quantity values('Banana', 100);
insert into Quantity values('Orange', 500);
insert into QUANTITY values('Chicken',30);
insert into Quantity values('Pork', 59);
insert into quantity values('Turkey', 79);
insert into quantity values('Fish', 39);
insert into quantity values('Celery', 99);
insert into quantity values('Spinach', 299);
insert into quantity values('Kale', 199);
insert into quantity values('Broccoli', 299);


insert into CATAGORY values('Apples', 'Fruit');
insert into CATAGORY values('Beef', 'Meat');
insert into CATAGORY values('Carrots', 'Vegetables');
insert into Catagory values('Grapes', 'Fruit');
insert into catagory values('Grapefruit', 'Fruit');
insert into catagory values('Banana', 'Fruit');
insert into catagory values('Orange', 'Fruit');
insert into CATAGORY values('Chicken' , 'Meat');
insert into catagory values('Pork', 'Meat');
insert into catagory values('Turkey', 'Meat');
insert into catagory values('Fish', 'Meat');
insert into catagory values('Celery', 'Vegetables');
insert into catagory values('Spinach', 'Vegetables');
insert into catagory values('Kale', 'Vegetables');
insert into catagory values('Broccoli', 'Vegetables');
